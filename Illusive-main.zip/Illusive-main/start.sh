npm run dev

echo "Next Server Running"