/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  amp: "true"
}

module.exports = nextConfig