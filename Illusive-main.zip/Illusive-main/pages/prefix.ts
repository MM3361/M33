export default {
  '/history': 'history',
  '/settings': 'settings',
  '/home': 'new',
  '/collection': 'collections'
}